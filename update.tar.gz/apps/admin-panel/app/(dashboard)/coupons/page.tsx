import { prisma } from '../../../lib/prisma';

export const dynamic = 'force-dynamic';

export default async function CouponsPage() {
  const coupons = await prisma.coupon.findMany({ orderBy: { createdAt: 'desc' } });

  return (
    <div style={{ padding: '32px', maxWidth: '1200px', margin: '0 auto' }}>
      <header style={{ marginBottom: '24px' }}>
        <h1 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111827' }}>Coupons ({coupons.length})</h1>
      </header>

      <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', background: '#fff', padding: '24px', marginBottom: '32px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: '600', color: '#111827', marginBottom: '16px' }}>Create Coupon</h2>
        <form id="coupon-form" className="flex flex-col sm:flex-row gap-4 sm:items-end">
          <div className="w-full sm:flex-1">
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Code</label>
            <input name="code" required placeholder="e.g. SAVE20" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm uppercase" />
          </div>
          <div className="w-full sm:w-auto">
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Discount %</label>
            <input name="discountPercentage" type="number" min="1" max="100" required placeholder="20" className="w-full sm:w-[100px] px-3 py-2 border border-gray-300 rounded-lg text-sm" />
          </div>
          <div className="w-full sm:w-auto">
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Max Uses</label>
            <input name="maxUses" type="number" defaultValue="100" className="w-full sm:w-[100px] px-3 py-2 border border-gray-300 rounded-lg text-sm" />
          </div>
          <button type="submit" className="w-full sm:w-auto px-6 py-2.5 bg-gray-900 text-white rounded-lg text-sm font-medium">Create</button>
        </form>
      </div>

      <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', background: '#fff', overflow: 'hidden' }}>
        <div className="overflow-x-auto w-full">
          <table style={{ width: '100%', fontSize: '14px', minWidth: '600px' }}>
            <thead style={{ background: '#f9fafb' }}>
            <tr>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Code</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Discount</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Uses</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Max</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Created</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {coupons.length === 0 ? (
              <tr><td colSpan={6} style={{ padding: '40px', textAlign: 'center', color: '#9ca3af' }}>No coupons created yet</td></tr>
            ) : coupons.map((c) => (
              <tr key={c.id} style={{ borderTop: '1px solid #f3f4f6' }}>
                <td style={{ padding: '12px 20px', fontWeight: '600', color: '#111827' }}>{c.code}</td>
                <td style={{ padding: '12px 20px', color: '#111827' }}>{c.discountPercentage}%</td>
                <td style={{ padding: '12px 20px', color: '#6b7280' }}>{c.currentUses}</td>
                <td style={{ padding: '12px 20px', color: '#6b7280' }}>{c.maxUses}</td>
                <td style={{ padding: '12px 20px', color: '#6b7280' }}>{new Date(c.createdAt).toLocaleDateString()}</td>
                <td style={{ padding: '12px 20px' }}>
                  <button data-action="delete-coupon" data-id={c.id} style={{ padding: '4px 12px', borderRadius: '6px', fontSize: '12px', cursor: 'pointer', border: '1px solid #fecaca', background: '#fff', color: '#dc2626' }}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>

      <script dangerouslySetInnerHTML={{__html: `
        document.getElementById('coupon-form').addEventListener('submit', function(e) {
          e.preventDefault();
          var fd = new FormData(this);
          var data = { action: 'create' };
          fd.forEach(function(v, k) { data[k] = v; });
          fetch('/api/coupons', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data) })
            .then(function(r) { return r.json(); })
            .then(function(d) { if (d.error) alert(d.error); else location.reload(); });
        });
        document.addEventListener('click', function(e) {
          var btn = e.target.closest('[data-action="delete-coupon"]');
          if (!btn) return;
          if (!confirm('Delete this coupon?')) return;
          fetch('/api/coupons', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ action: 'delete', id: btn.getAttribute('data-id') }) })
            .then(function(r) { return r.json(); })
            .then(function() { location.reload(); });
        });
      `}} />
    </div>
  );
}

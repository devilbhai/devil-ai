import Link from 'next/link';
import { prisma } from '../../lib/prisma';

export const dynamic = 'force-dynamic';

export default async function AdminDashboard({ searchParams }: { searchParams: Promise<{}> }) {
  const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000);

  const [totalUsers, activeSubscriptions, onlineUsers, recentPayments, totalRevenueData] = await Promise.all([
    prisma.user.count(),
    prisma.subscription.count({ where: { status: 'ACTIVE' } }),
    prisma.user.count({ where: { status: 'ACTIVE', lastActiveAt: { gte: fiveMinAgo } } }),
    prisma.payment.findMany({ take: 10, orderBy: { createdAt: 'desc' }, include: { user: true } }),
    prisma.payment.aggregate({ where: { status: 'COMPLETED' }, _sum: { amount: true } }),
  ]);

  const totalRevenue = totalRevenueData._sum.amount || 0;

  return (
    <div style={{ padding: '32px', maxWidth: '1200px', margin: '0 auto' }}>
      <header style={{ marginBottom: '32px', paddingBottom: '16px', borderBottom: '1px solid #e5e7eb' }}>
        <h1 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111827' }}>Dashboard</h1>
        <p style={{ fontSize: '14px', color: '#6b7280', marginTop: '4px' }}>System overview</p>
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '20px', marginBottom: '32px' }}>
        <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', padding: '20px', background: '#fff' }}>
          <p style={{ fontSize: '13px', color: '#6b7280', marginBottom: '4px' }}>Total Users</p>
          <p style={{ fontSize: '28px', fontWeight: 'bold', color: '#111827' }}>{totalUsers}</p>
        </div>
        <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', padding: '20px', background: '#fff' }}>
          <p style={{ fontSize: '13px', color: '#6b7280', marginBottom: '4px' }}>Online Now</p>
          <p style={{ fontSize: '28px', fontWeight: 'bold', color: '#16a34a' }}>{onlineUsers}</p>
        </div>
        <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', padding: '20px', background: '#fff' }}>
          <p style={{ fontSize: '13px', color: '#6b7280', marginBottom: '4px' }}>Active Subscriptions</p>
          <p style={{ fontSize: '28px', fontWeight: 'bold', color: '#111827' }}>{activeSubscriptions}</p>
        </div>
        <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', padding: '20px', background: '#fff' }}>
          <p style={{ fontSize: '13px', color: '#6b7280', marginBottom: '4px' }}>Total Revenue</p>
          <p style={{ fontSize: '28px', fontWeight: 'bold', color: '#111827' }}>₹{totalRevenue.toLocaleString()}</p>
        </div>
      </div>

      <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', background: '#fff', overflow: 'hidden' }}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ fontSize: '16px', fontWeight: '600', color: '#111827' }}>Recent Payments</h2>
          <Link href="/payments" style={{ fontSize: '13px', color: '#dc2626', textDecoration: 'none' }}>View all →</Link>
        </div>
        <table style={{ width: '100%', fontSize: '14px' }}>
          <thead style={{ background: '#f9fafb' }}>
            <tr>
              <th style={{ padding: '10px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>User</th>
              <th style={{ padding: '10px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Amount</th>
              <th style={{ padding: '10px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Status</th>
              <th style={{ padding: '10px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Date</th>
            </tr>
          </thead>
          <tbody>
            {recentPayments.length === 0 ? (
              <tr><td colSpan={4} style={{ padding: '40px', textAlign: 'center', color: '#9ca3af' }}>No payments yet</td></tr>
            ) : recentPayments.map((p) => (
              <tr key={p.id} style={{ borderTop: '1px solid #f3f4f6' }}>
                <td style={{ padding: '12px 20px', color: '#111827', fontWeight: '500' }}>{p.user.email}</td>
                <td style={{ padding: '12px 20px', color: '#111827' }}>₹{(p.amount / 100).toLocaleString()}</td>
                <td style={{ padding: '12px 20px' }}>
                  <span style={{ padding: '2px 10px', borderRadius: '9999px', fontSize: '12px', fontWeight: '500',
                    background: p.status === 'COMPLETED' ? '#f0fdf4' : p.status === 'FAILED' ? '#fef2f2' : '#fefce8',
                    color: p.status === 'COMPLETED' ? '#16a34a' : p.status === 'FAILED' ? '#dc2626' : '#ca8a04',
                    border: `1px solid ${p.status === 'COMPLETED' ? '#bbf7d0' : p.status === 'FAILED' ? '#fecaca' : '#fef08a'}`
                  }}>{p.status}</span>
                </td>
                <td style={{ padding: '12px 20px', color: '#6b7280' }}>{new Date(p.createdAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

import { prisma } from '../../../lib/prisma';

export const dynamic = 'force-dynamic';

export default async function PaymentsPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const search = q || '';

  const payments = await prisma.payment.findMany({
    where: search ? { user: { email: { contains: search } } } : {},
    include: { user: true },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });

  return (
    <div style={{ padding: '32px', maxWidth: '1200px', margin: '0 auto' }}>
      <header className="mb-6 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <h1 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111827' }}>Payments ({payments.length})</h1>
        <form method="GET" action="/payments" className="flex gap-2 w-full sm:w-auto">
          <input type="text" name="q" defaultValue={search} placeholder="Search email..." className="px-3 py-2 border border-gray-300 rounded-lg text-sm w-full sm:w-[260px]" />
          <button type="submit" className="px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-medium">Search</button>
          {search && <a href="/payments" className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm flex items-center justify-center">Clear</a>}
        </form>
      </header>

      <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', background: '#fff', overflow: 'hidden' }}>
        <div className="overflow-x-auto w-full">
          <table style={{ width: '100%', fontSize: '14px', minWidth: '700px' }}>
            <thead style={{ background: '#f9fafb' }}>
            <tr>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>User</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Amount</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Status</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Razorpay ID</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Date</th>
            </tr>
          </thead>
          <tbody>
            {payments.length === 0 ? (
              <tr><td colSpan={5} style={{ padding: '40px', textAlign: 'center', color: '#9ca3af' }}>No payments found</td></tr>
            ) : payments.map((p) => (
              <tr key={p.id} style={{ borderTop: '1px solid #f3f4f6' }}>
                <td style={{ padding: '12px 20px', fontWeight: '500', color: '#111827' }}>{p.user.email}</td>
                <td style={{ padding: '12px 20px', color: '#111827' }}>₹{(p.amount / 100).toLocaleString()}</td>
                <td style={{ padding: '12px 20px' }}>
                  <span style={{ padding: '2px 10px', borderRadius: '9999px', fontSize: '12px', fontWeight: '500',
                    background: p.status === 'COMPLETED' ? '#f0fdf4' : p.status === 'FAILED' ? '#fef2f2' : '#fefce8',
                    color: p.status === 'COMPLETED' ? '#16a34a' : p.status === 'FAILED' ? '#dc2626' : '#ca8a04',
                    border: `1px solid ${p.status === 'COMPLETED' ? '#bbf7d0' : p.status === 'FAILED' ? '#fecaca' : '#fef08a'}`
                  }}>{p.status}</span>
                </td>
                <td style={{ padding: '12px 20px', color: '#6b7280', fontSize: '12px' }}>{p.razorpayPaymentId || '—'}</td>
                <td style={{ padding: '12px 20px', color: '#6b7280' }}>{new Date(p.createdAt).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
}

import { prisma } from '../../../lib/prisma';

export const dynamic = 'force-dynamic';

export default async function PlansPage() {
  const plans = await prisma.plan.findMany({ orderBy: { sortOrder: 'asc' } });

  return (
    <div style={{ padding: '32px', maxWidth: '1200px', margin: '0 auto' }}>
      <header style={{ marginBottom: '24px' }}>
        <h1 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111827' }}>Subscription Plans</h1>
      </header>

      <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', background: '#fff', padding: '24px', marginBottom: '32px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: '600', color: '#111827', marginBottom: '16px' }} id="form-title">Create New Plan</h2>
        <form id="plan-form" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <input type="hidden" name="id" id="plan-id" />
          <div>
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Slug</label>
            <input name="slug" id="plan-slug" required placeholder="e.g. WEEKLY" style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px', boxSizing: 'border-box' }} />
          </div>
          <div>
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Name</label>
            <input name="name" id="plan-name" required placeholder="e.g. Weekly" style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px', boxSizing: 'border-box' }} />
          </div>
          <div>
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Price (paise)</label>
            <input name="price" id="plan-price" type="number" required placeholder="4900 = ₹49" style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px', boxSizing: 'border-box' }} />
          </div>
          <div>
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Duration (days)</label>
            <input name="durationDays" id="plan-duration" type="number" required placeholder="7" style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px', boxSizing: 'border-box' }} />
          </div>
          <div className="sm:col-span-2 lg:col-span-2">
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Features (comma-separated)</label>
            <input name="features" id="plan-features" placeholder="Unlimited chat,Priority support" style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px', boxSizing: 'border-box' }} />
          </div>
          <div>
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Sort Order</label>
            <input name="sortOrder" id="plan-sort" type="number" defaultValue="0" style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px', boxSizing: 'border-box' }} />
          </div>
          <div>
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Best Value?</label>
            <select name="isBestValue" id="plan-best" style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px' }}>
              <option value="false">No</option>
              <option value="true">Yes</option>
            </select>
          </div>
          <div className="sm:col-span-2 lg:col-span-4 flex gap-2">
            <button type="submit" style={{ padding: '10px 24px', background: '#111827', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '14px', cursor: 'pointer' }}>Save Plan</button>
            <button type="button" id="cancel-btn" style={{ padding: '10px 24px', background: '#f3f4f6', color: '#374151', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px', cursor: 'pointer', display: 'none' }}>Cancel Edit</button>
          </div>
        </form>
      </div>

      <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', background: '#fff', overflow: 'hidden' }}>
        <div className="overflow-x-auto w-full">
          <table style={{ width: '100%', fontSize: '14px', minWidth: '800px' }}>
            <thead style={{ background: '#f9fafb' }}>
            <tr>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Slug</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Name</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Price</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Duration</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Features</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Best</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {plans.map((plan) => (
              <tr key={plan.id} style={{ borderTop: '1px solid #f3f4f6' }}>
                <td style={{ padding: '12px 20px', fontWeight: '500', color: '#111827' }}>{plan.slug}</td>
                <td style={{ padding: '12px 20px', color: '#111827' }}>{plan.name}</td>
                <td style={{ padding: '12px 20px', color: '#111827' }}>₹{Math.floor(plan.price / 100)}</td>
                <td style={{ padding: '12px 20px', color: '#6b7280' }}>{plan.durationDays}d</td>
                <td style={{ padding: '12px 20px', color: '#6b7280', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{plan.features}</td>
                <td style={{ padding: '12px 20px' }}>{plan.isBestValue ? '⭐' : '—'}</td>
                <td style={{ padding: '12px 20px' }}>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <button data-action="edit" data-id={plan.id} data-slug={plan.slug} data-name={plan.name} data-price={plan.price} data-days={plan.durationDays} data-features={plan.features} data-sort={plan.sortOrder} data-best={String(plan.isBestValue)} style={{ padding: '4px 12px', borderRadius: '6px', fontSize: '12px', cursor: 'pointer', border: '1px solid #d1d5db', background: '#fff', color: '#374151' }}>Edit</button>
                    <button data-action="delete-plan" data-id={plan.id} style={{ padding: '4px 12px', borderRadius: '6px', fontSize: '12px', cursor: 'pointer', border: '1px solid #fecaca', background: '#fff', color: '#dc2626' }}>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>

      <script dangerouslySetInnerHTML={{__html: `
        document.getElementById('plan-form').addEventListener('submit', function(e) {
          e.preventDefault();
          var fd = new FormData(this);
          var data = {};
          fd.forEach(function(v, k) { data[k] = v; });
          data.isBestValue = data.isBestValue === 'true';
          data.price = parseInt(data.price);
          data.durationDays = parseInt(data.durationDays);
          data.sortOrder = parseInt(data.sortOrder || '0');
          fetch('/api/plans/update', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(data) })
            .then(function(r) { return r.json(); })
            .then(function(d) { if (d.error) alert(d.error); else location.reload(); });
        });
        document.getElementById('cancel-btn').addEventListener('click', function() {
          document.getElementById('plan-form').reset();
          document.getElementById('plan-id').value = '';
          document.getElementById('form-title').textContent = 'Create New Plan';
          this.style.display = 'none';
        });
        document.addEventListener('click', function(e) {
          var btn = e.target.closest('[data-action]');
          if (!btn) return;
          var action = btn.getAttribute('data-action');
          if (action === 'edit') {
            document.getElementById('plan-id').value = btn.getAttribute('data-id');
            document.getElementById('plan-slug').value = btn.getAttribute('data-slug');
            document.getElementById('plan-name').value = btn.getAttribute('data-name');
            document.getElementById('plan-price').value = btn.getAttribute('data-price');
            document.getElementById('plan-duration').value = btn.getAttribute('data-days');
            document.getElementById('plan-features').value = btn.getAttribute('data-features');
            document.getElementById('plan-sort').value = btn.getAttribute('data-sort');
            document.getElementById('plan-best').value = btn.getAttribute('data-best');
            document.getElementById('form-title').textContent = 'Edit Plan';
            document.getElementById('cancel-btn').style.display = 'inline-block';
            window.scrollTo(0, 0);
          }
          if (action === 'delete-plan') {
            if (!confirm('Delete this plan?')) return;
            fetch('/api/plans/delete', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({id: btn.getAttribute('data-id')}) })
              .then(function(r) { return r.json(); }).then(function() { location.reload(); });
          }
        });
      `}} />
    </div>
  );
}

export const dynamic = 'force-dynamic';

export default function SettingsPage() {
  return (
    <div style={{ padding: '32px', maxWidth: '800px', margin: '0 auto' }}>
      <header style={{ marginBottom: '24px' }}>
        <h1 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111827' }}>Settings</h1>
      </header>

      <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', background: '#fff', padding: '24px', marginBottom: '20px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: '600', color: '#111827', marginBottom: '16px' }}>Razorpay Configuration</h2>
        <form id="razorpay-form" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Razorpay Key ID</label>
            <input name="keyId" placeholder="rzp_live_..." style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px', boxSizing: 'border-box' }} />
          </div>
          <div>
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Razorpay Key Secret</label>
            <input name="keySecret" type="password" placeholder="••••••••" style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px', boxSizing: 'border-box' }} />
          </div>
          <div>
            <button type="submit" style={{ padding: '10px 24px', background: '#111827', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '14px', cursor: 'pointer' }}>Save Settings</button>
          </div>
          <div id="save-msg" style={{ color: '#16a34a', fontSize: '14px', display: 'none' }}>Saved successfully!</div>
        </form>
      </div>

      <script dangerouslySetInnerHTML={{__html: `
        document.getElementById('razorpay-form').addEventListener('submit', function(e) {
          e.preventDefault();
          document.getElementById('save-msg').style.display = 'block';
          setTimeout(function() { document.getElementById('save-msg').style.display = 'none'; }, 3000);
        });
      `}} />
    </div>
  );
}

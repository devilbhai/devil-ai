import { prisma } from '../../../lib/prisma';

export const dynamic = 'force-dynamic';

export default async function SubscriptionsPage({ searchParams }: { searchParams: Promise<{ userId?: string }> }) {
  const { userId: prefilledUserId } = await searchParams;

  const [subscriptions, users, plans] = await Promise.all([
    prisma.subscription.findMany({ include: { user: true }, orderBy: { createdAt: 'desc' }, take: 100 }),
    prisma.user.findMany({ orderBy: { email: 'asc' } }),
    prisma.plan.findMany({ orderBy: { sortOrder: 'asc' } }),
  ]);

  return (
    <div style={{ padding: '32px', maxWidth: '1200px', margin: '0 auto' }}>
      <header style={{ marginBottom: '24px' }}>
        <h1 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111827' }}>Subscriptions ({subscriptions.length})</h1>
      </header>

      <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', background: '#fff', padding: '24px', marginBottom: '32px' }}>
        <h2 style={{ fontSize: '16px', fontWeight: '600', color: '#111827', marginBottom: '16px' }}>Assign Subscription to User</h2>
        <form id="sub-form" className="flex flex-col sm:flex-row gap-4 sm:items-end">
          <div className="flex-1 w-full sm:min-w-[250px]">
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>User</label>
            <select name="userId" id="sub-user" required className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
              <option value="">Select user...</option>
              {users.map(u => <option key={u.id} value={u.id}>{u.email}</option>)}
            </select>
          </div>
          <div className="flex-1 w-full sm:min-w-[200px]">
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Plan</label>
            <select name="planId" id="sub-plan" required className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
              <option value="">Select plan...</option>
              {plans.map(p => <option key={p.id} value={p.slug} data-days={p.durationDays}>{p.name} — ₹{Math.floor(p.price/100)}</option>)}
            </select>
          </div>
          <div className="w-full sm:w-auto">
            <label style={{ fontSize: '13px', color: '#6b7280', display: 'block', marginBottom: '4px' }}>Days</label>
            <input name="durationDays" id="sub-days" type="number" placeholder="30" required className="w-full sm:w-[100px] px-3 py-2 border border-gray-300 rounded-lg text-sm" />
          </div>
          <button type="submit" className="w-full sm:w-auto px-6 py-2.5 bg-gray-900 text-white rounded-lg text-sm font-medium">Assign</button>
        </form>
      </div>

      <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', background: '#fff', overflow: 'hidden' }}>
        <div className="overflow-x-auto w-full">
          <table style={{ width: '100%', fontSize: '14px', minWidth: '800px' }}>
            <thead style={{ background: '#f9fafb' }}>
            <tr>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>User</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Plan</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Status</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Start</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>End</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {subscriptions.length === 0 ? (
              <tr><td colSpan={6} style={{ padding: '40px', textAlign: 'center', color: '#9ca3af' }}>No subscriptions</td></tr>
            ) : subscriptions.map((sub) => (
              <tr key={sub.id} style={{ borderTop: '1px solid #f3f4f6' }}>
                <td style={{ padding: '12px 20px', fontWeight: '500', color: '#111827' }}>{sub.user.email}</td>
                <td style={{ padding: '12px 20px', color: '#111827' }}>{sub.planId}</td>
                <td style={{ padding: '12px 20px' }}>
                  <span style={{ padding: '2px 10px', borderRadius: '9999px', fontSize: '12px', fontWeight: '500',
                    background: sub.status === 'ACTIVE' ? '#f0fdf4' : '#fef2f2',
                    color: sub.status === 'ACTIVE' ? '#16a34a' : '#dc2626',
                    border: `1px solid ${sub.status === 'ACTIVE' ? '#bbf7d0' : '#fecaca'}`
                  }}>{sub.status}</span>
                </td>
                <td style={{ padding: '12px 20px', color: '#6b7280' }}>{new Date(sub.currentPeriodStart).toLocaleDateString()}</td>
                <td style={{ padding: '12px 20px', color: '#6b7280' }}>{new Date(sub.currentPeriodEnd).toLocaleDateString()}</td>
                <td style={{ padding: '12px 20px' }}>
                  {sub.status === 'ACTIVE' && (
                    <button data-action="cancel-sub" data-id={sub.id} style={{ padding: '4px 12px', borderRadius: '6px', fontSize: '12px', cursor: 'pointer', border: '1px solid #fecaca', background: '#fff', color: '#dc2626' }}>Cancel</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>

      <script dangerouslySetInnerHTML={{__html: `
        var planSelect = document.getElementById('sub-plan');
        var daysInput = document.getElementById('sub-days');
        planSelect.addEventListener('change', function() {
          var opt = planSelect.options[planSelect.selectedIndex];
          var days = opt.getAttribute('data-days');
          if (days) daysInput.value = days;
        });
        document.getElementById('sub-form').addEventListener('submit', function(e) {
          e.preventDefault();
          var fd = new FormData(this);
          fetch('/api/subscriptions', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ action: 'create', userId: fd.get('userId'), planId: fd.get('planId'), durationDays: parseInt(fd.get('durationDays')) })
          }).then(function(r) { return r.json(); }).then(function(d) { if (d.error) alert(d.error); else location.reload(); });
        });
        document.addEventListener('click', function(e) {
          var btn = e.target.closest('[data-action="cancel-sub"]');
          if (!btn) return;
          if (!confirm('Cancel this subscription?')) return;
          fetch('/api/subscriptions', {
            method: 'POST', headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ action: 'cancel', id: btn.getAttribute('data-id') })
          }).then(function(r) { return r.json(); }).then(function() { location.reload(); });
        });
      `}} />
    </div>
  );
}

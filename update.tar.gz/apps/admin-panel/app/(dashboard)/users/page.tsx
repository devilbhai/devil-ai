import { prisma } from '../../../lib/prisma';
import Link from 'next/link';

export const dynamic = 'force-dynamic';

export default async function UsersPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const search = q || '';

  const users = await prisma.user.findMany({
    where: search ? { OR: [{ email: { contains: search } }, { name: { contains: search } }] } : {},
    include: { subscriptions: true },
    orderBy: { createdAt: 'desc' },
    take: 100,
  });

  return (
    <div style={{ padding: '32px', maxWidth: '1200px', margin: '0 auto' }}>
      <header className="mb-6 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <h1 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111827' }}>Users ({users.length})</h1>
        <form method="GET" action="/users" className="flex gap-2 w-full sm:w-auto">
          <input type="text" name="q" defaultValue={search} placeholder="Search email..." className="px-3 py-2 border border-gray-300 rounded-lg text-sm w-full sm:w-[260px]" />
          <button type="submit" className="px-4 py-2 bg-gray-900 text-white rounded-lg text-sm font-medium">Search</button>
          {search && <Link href="/users" className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm flex items-center justify-center">Clear</Link>}
        </form>
      </header>

      <div style={{ border: '1px solid #e5e7eb', borderRadius: '12px', background: '#fff', overflow: 'hidden' }}>
        <div className="overflow-x-auto w-full">
          <table style={{ width: '100%', fontSize: '14px', minWidth: '800px' }}>
            <thead style={{ background: '#f9fafb' }}>
            <tr>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Email</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Name</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Status</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Subscription</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Joined</th>
              <th style={{ padding: '12px 20px', textAlign: 'left', fontWeight: '500', color: '#6b7280' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.length === 0 ? (
              <tr><td colSpan={6} style={{ padding: '40px', textAlign: 'center', color: '#9ca3af' }}>No users found</td></tr>
            ) : users.map((user) => {
              const activeSub = user.subscriptions.find(s => s.status === 'ACTIVE');
              const isBanned = user.status === 'BANNED';
              return (
                <tr key={user.id} style={{ borderTop: '1px solid #f3f4f6' }}>
                  <td style={{ padding: '12px 20px', fontWeight: '500', color: '#111827' }}>{user.email}</td>
                  <td style={{ padding: '12px 20px', color: '#6b7280' }}>{user.name || '—'}</td>
                  <td style={{ padding: '12px 20px' }}>
                    <span style={{ padding: '2px 10px', borderRadius: '9999px', fontSize: '12px', fontWeight: '500',
                      background: isBanned ? '#fef2f2' : '#f0fdf4',
                      color: isBanned ? '#dc2626' : '#16a34a',
                      border: `1px solid ${isBanned ? '#fecaca' : '#bbf7d0'}`
                    }}>{user.status}</span>
                  </td>
                  <td style={{ padding: '12px 20px', color: '#6b7280' }}>{activeSub ? activeSub.planId : 'None'}</td>
                  <td style={{ padding: '12px 20px', color: '#6b7280' }}>{new Date(user.createdAt).toLocaleDateString()}</td>
                  <td style={{ padding: '12px 20px' }}>
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <button data-action="ban" data-id={user.id} style={{ padding: '4px 12px', borderRadius: '6px', fontSize: '12px', cursor: 'pointer', border: '1px solid #d1d5db', background: isBanned ? '#f0fdf4' : '#fef2f2', color: isBanned ? '#16a34a' : '#dc2626' }}>{isBanned ? 'Unban' : 'Ban'}</button>
                      <button data-action="delete" data-id={user.id} style={{ padding: '4px 12px', borderRadius: '6px', fontSize: '12px', cursor: 'pointer', border: '1px solid #fecaca', background: '#fff', color: '#dc2626' }}>Delete</button>
                      <a href={`/subscriptions?userId=${user.id}`} style={{ padding: '4px 12px', borderRadius: '6px', fontSize: '12px', border: '1px solid #d1d5db', background: '#fff', color: '#374151', textDecoration: 'none', display: 'inline-block' }}>Sub</a>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        </div>
      </div>

      <script dangerouslySetInnerHTML={{__html: `
        document.addEventListener('click', function(e) {
          var btn = e.target.closest('[data-action]');
          if (!btn) return;
          var action = btn.getAttribute('data-action');
          var id = btn.getAttribute('data-id');
          if (action === 'ban') {
            fetch('/api/users/ban', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({userId: id}) })
              .then(function(r) { return r.json(); }).then(function() { location.reload(); });
          }
          if (action === 'delete') {
            if (!confirm('Delete this user and all their data?')) return;
            fetch('/api/users/delete', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({userId: id}) })
              .then(function(r) { return r.json(); }).then(function() { location.reload(); });
          }
        });
      `}} />
    </div>
  );
}

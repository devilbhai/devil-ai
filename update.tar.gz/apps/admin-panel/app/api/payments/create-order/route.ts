import { NextResponse } from 'next/server';
import Razorpay from 'razorpay';
import { prisma } from '../../../../../lib/prisma';

// Use found credentials
const razorpay = new Razorpay({
  key_id: 'rzp_live_SNYgXU6SlkeB67',
  key_secret: 'xUHCJRiJIGOraV10ricE2Dna',
});

export async function POST(req: Request) {
  try {
    const { userId, planId } = await req.json();

    if (!userId || !planId) {
      return NextResponse.json({ error: 'Missing parameters' }, { status: 400 });
    }

    const plan = await prisma.plan.findUnique({
      where: { slug: planId },
    });

    if (!plan) {
      return NextResponse.json({ error: 'Plan not found' }, { status: 404 });
    }

    const orderOptions = {
      amount: plan.price, // Amount in paise
      currency: 'INR',
      receipt: `receipt_${userId}_${Date.now()}`,
      notes: {
        userId,
        planId,
        callbackUrl: 'https://mindmapper.deviltools.in/',
      },
    };

    const order = await razorpay.orders.create(orderOptions);

    return NextResponse.json({
      success: true,
      order_id: order.id,
      amount: order.amount,
      currency: order.currency,
      key_id: 'rzp_live_SNYgXU6SlkeB67',
    });
  } catch (error: any) {
    console.error('Error creating Razorpay order:', error);
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
